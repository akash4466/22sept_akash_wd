from django.contrib import admin
from django.urls import path,include
from .import views

urlpatterns = [
    path('',views.index,name='index'),
   
    path('showdata/',views.showdata,name='showdata'),
    path('delete/<int:id>/',views.deletedata,name='deletedata'),
    path('update/<int:id>/',views.update,name='update'),
    
]