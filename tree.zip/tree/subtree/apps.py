from django.apps import AppConfig


class SubtreeConfig(AppConfig):
    name = 'subtree'
