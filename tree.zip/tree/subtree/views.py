from django.shortcuts import render, redirect
from .models import student


# Home Page + Insert Data
def index(request):

    if request.method == 'POST':

        name = request.POST['name']
        email = request.POST['email']
        mobile = request.POST['mobile']

        student.objects.create(
            name=name,
            email=email,
            mobile=mobile
        )

        return redirect('showdata')

    return render(request, 'index.html')


# Show Data
def showdata(request):

    data = student.objects.all()

    return render(request, 'showdata.html', {'data': data})


# Delete Data
def deletedata(request, id):

    data = student.objects.get(id=id)

    data.delete()

    return redirect('showdata')


# Update Data
def update(request, id):

    data = student.objects.get(id=id)

    if request.method == 'POST':

        data.name = request.POST['name']
        data.email = request.POST['email']
        data.mobile = request.POST['mobile']

        data.save()

        return redirect('showdata')

    return render(request, 'update.html', {'data': data})