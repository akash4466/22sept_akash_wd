from django import forms
from .models import student
class studentform(forms.ModelForm):
    class meta:
        model = student

        fields=['name','email','mobile']